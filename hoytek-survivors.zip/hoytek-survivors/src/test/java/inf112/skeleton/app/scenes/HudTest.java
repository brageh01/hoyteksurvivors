package inf112.skeleton.app.scenes;

public class HudTest {
    
}
